﻿using System;

namespace CapaException
{
    public class AccesoException : Exception
    {
        public AccesoException(string message) : base(message) { }
    }

}
